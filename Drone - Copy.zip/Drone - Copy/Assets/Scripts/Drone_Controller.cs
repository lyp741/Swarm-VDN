﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Drone_Controller : MonoBehaviour {

	private MLPlayer.Agent m_agent;
	public GameObject FLR;
	public GameObject FRR;
	public GameObject BLR;
	public GameObject BRR;
	public Rigidbody Body;
	private Vector3 Lift;
	private Vector3 pitchSpeed;
	private Vector3 rollSpeed;
	private Vector3 yawSpeed;


	public float thrust;
	public float pitch;
	public float roll;
	public float yaw;


	// Use this for initialization
	void Start () {
		m_agent = GetComponent<MLPlayer.Agent> ();
		if (m_agent == null) {
			Debug.Log ("GetComponent<MLPlayer.Agent> () was null.");
		}
		thrust = 490.5f;
		Vector3 Lift = new Vector3 (0, 0, 0);
		Vector3 pitchSpeed = new Vector3 (0, 0, 0);
		Vector3 rollSpeed = new Vector3 (0, 0, 0);
		Vector3 yawSpeed = new Vector3 (0, 0, 0);
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void FixedUpdate(){
		yaw = 0;
		pitch = 0;
		roll = 0;
		thrust = 490.5f;

		if (Input.GetKey ("w")) {
			thrust = 540f;
		}
		if (Input.GetKey ("s")) {
			thrust = 440;
		}

			
		if (Input.GetKey ("e")) {
			yaw = +100f;
		} 
		if (Input.GetKey ("q")) {
			yaw = -100f;
		}
	
		if (Input.GetKey ("up")) {
			pitch = +60f;
		}
		if (Input.GetKey ("down")) {
			pitch = -60f;
		}
		if (Input.GetKey ("right")) {
			roll = +60f;
		}
		if (Input.GetKey ("left")) {
			roll = -60f;
		} 
		/*
		Lift = transform.up * (thrust);
		yawSpeed = transform.up * (yaw);
		rollSpeed = transform.right * (roll);
		pitchSpeed = transform.forward * (pitch);
		*/

		Lift = transform.up * ((m_agent.action.thrustValue));
		yawSpeed = transform.up * (yaw + (m_agent.action.yawValue));
		rollSpeed = transform.right * (roll + (m_agent.action.rollValue));
		pitchSpeed = transform.forward * (pitch + (m_agent.action.pitchValue));

		FLR.transform.Rotate (0,0,200);
		FRR.transform.Rotate (0,0,200);
		BLR.transform.Rotate (0,0,200);
		BRR.transform.Rotate (0,0,200);

		Body.AddForce (Lift*Time.deltaTime, ForceMode.Force);
		Body.AddTorque (pitchSpeed * Time.deltaTime, ForceMode.Force);
		Body.AddTorque (rollSpeed * Time.deltaTime, ForceMode.Force);
		Body.AddTorque (yawSpeed * Time.deltaTime, ForceMode.Force);



	
	
	}






}
