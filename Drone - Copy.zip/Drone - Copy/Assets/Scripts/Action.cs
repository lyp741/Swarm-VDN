﻿using UnityEngine;
using System.Collections.Generic;

namespace MLPlayer {
	public class Action {
		public float thrustValue;
		public float yawValue;
		public float pitchValue;
		public float rollValue;
		public float right_Wheel;
		public float left_Wheel;
		public float fLR;
		public float fRR;
		public float bLR;
		public float bRR;

		public void Clear() {
			right_Wheel = 0;
			left_Wheel = 0;
			fLR = 0;
			fRR = 0;
			bLR = 0;
			bRR = 0;
			yawValue = 0;
			pitchValue = 0;
			rollValue = 0;
			thrustValue = 490.5f;
		}

		

		public void Set(string command) {
			switch (command) {
			case "0":
				right_Wheel = 1;
				left_Wheel = 1;
				fLR = 0;
				fRR = 0;
				bLR = 0;
				bRR = 0;
				yawValue = 0;
				pitchValue = 0;
				rollValue = 0;
				thrustValue = 490.5f;
				break;
			case "1":
				right_Wheel = 2;//1
				left_Wheel = 2;//1
				fLR = 0.3f;
				fRR = 0.3f;
				bLR = 0.3f;
				bRR = 0.3f;
				yawValue = 0;
				pitchValue = 0;
				rollValue = 0;
				thrustValue = 540f;
				break;
			case "2":
				right_Wheel = 2;//1
				left_Wheel = -2;//-1
				fLR = 0.5f;
				fRR = 0.5f;
				bLR = 0.5f;
				bRR = 0.5f;
				yawValue = 0;
				pitchValue = 0;
				rollValue = 0;
				thrustValue = 440f;
				break;
			case "3":
				right_Wheel = -2;//-1
				left_Wheel = 2;//1
				fLR = 0.1f;
				fRR = 0;
				bLR = 0;
				bRR = 0.1f;
				yawValue = 100;
				pitchValue = 0;
				rollValue = 0;
				thrustValue = 490.5f;
				break;
			case "4":
				right_Wheel = 2;//1
				left_Wheel = 0;//0
				fLR = -1f;
				fRR = -1f;
				bLR = -1f;
				bRR = -1f;
				yawValue = -100;
				pitchValue = 0;
				rollValue = 0;
				thrustValue = 490.5f;
				break;
			case "5":
				right_Wheel = 0;//0
				left_Wheel = 2;//1
				fLR = 0.1f;
				fRR = 0.1f;
				bLR = 0;
				bRR = 0;
				yawValue = 0;
				pitchValue = 60;
				rollValue = 0;
				thrustValue = 490.5f;
				break;
			case "6":
				right_Wheel = 1;//0.5f
				left_Wheel = 2;//1
				fLR = 0;
				fRR = 0;
				bLR = 0.1f;
				bRR = 0.1f;
				yawValue = 0;
				pitchValue = -60;
				rollValue = 0;
				thrustValue = 490.5f;
				break;
			case "7":
				right_Wheel = 2;//1
				left_Wheel = 1;//0.5f
				fLR = 0;
				fRR = 0.1f;
				bLR = 0.1f;
				bRR = 0;
				yawValue = 0;
				pitchValue = 0;
				rollValue = 60;
				thrustValue = 490.5f;
				break;
			case "8":
				right_Wheel = 2;//1
				left_Wheel = 1;//0.5f
				fLR = 0;
				fRR = 0.1f;
				bLR = 0.1f;
				bRR = 0;
				yawValue = 0;
				pitchValue = 0;
				rollValue = -60;
				thrustValue = 490.5f;
				break;
			}
		}
	}
}