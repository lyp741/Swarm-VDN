﻿using UnityEngine;
using System.Collections.Generic;
using System.Threading;
using MsgPack;


namespace MLPlayer
{
public class LandmarkMove : MonoBehaviour {
	public GameObject pole;
		private Vector3 position1;
		private Vector3 position2;
		private Vector3 position3;



	// Use this for initialization
	void Start () {
			position1 = new Vector3 (0,3,-25);
			position2 = new Vector3 (0, 3, 25);
			position3 = new Vector3 (-25, 3, 0);
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	public void changePosition1(){
			pole.transform.position = position1;
	}
	public void changePosition2(){
			pole.transform.position = position2;
	}
	public void changePosition3(){
			pole.transform.position = position3;
		
	}

	



	}
}
