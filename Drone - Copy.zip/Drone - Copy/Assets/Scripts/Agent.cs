﻿ using UnityEngine;
using System.Collections.Generic;
using System.IO;
using WebSocketSharp;
using System.Threading;

namespace MLPlayer {
	public class Agent : MonoBehaviour {
		[SerializeField] List<Camera> rgbCameras;
		[SerializeField] List<Camera> depthCameras;
		[SerializeField] List<Texture2D> rgbImages;
		[SerializeField] List<Texture2D> depthImages;
		[SerializeField] List<IRSensor> irSensors;
		[SerializeField] List<IRSensor> groundSensor;
		[SerializeField] List<gyroscope> GyroSensor;
		[SerializeField] GameObject Ring;
		[SerializeField] List<GameObject> Led;
		[SerializeField] GameObject Goal;

		public SceneController sc;
		public Action action { set; get; }
		public State state { set; get; }
		public Force force;
		public GameObject Center;
		public int line_length_pre;
		public int line_length;
		public int line_left;
		public int line_right;
		public bool line_flag;
		public bool coll;
		public int mate_pixels;
		public int mate_pixels_pre;
		public Color targetCol;
		public Color mateCol;
		public Color nestCol;
		public int nestColArea;
		public int nestColArea_pre;
		public int foodColArea;
		public int rotationTempX;
		public int rotationTempZ;
		public float pooldistance;
		public float pooldistance_pre;
		public float centerdistance;
		public float centerdistance_pre;
		public Vector3 tempdist;
		public Vector3 tempdist2;
	
		public GameObject target;
		/*void OnCollisionEnter(Collision col){
			if (col.gameObject.tag == "Plane") {
				coll = true;Debug.Log ("coll=true");
			}else{coll = false;Debug.Log ("coll=false");}

		
		}*/








		public void UpdateState ()
		{
			if (state.target [0] [0] == 255) {
				targetCol = new Color (1, 1, 0, 1);//will delete this part later on
				mateCol = Color.green;// 1 1 0 1 = yellow; color of food
				nestCol = new Color (0, 1, 1, 1);
				target = GameObject.FindGameObjectWithTag("0");
			} else if (state.target [0] [1] == 255) {
				targetCol = new Color (0, 1, 1, 1);
				mateCol = Color.green;
				nestCol = new Color (1, 1, 0, 1);
				target = GameObject.FindGameObjectWithTag("1");

			}

			state.image = new byte[rgbCameras.Count][];
			for (int i=0; i<rgbCameras.Count; i++) {
				Texture2D txture = rgbImages [i];
				state.image[i] = GetCameraImage (rgbCameras[i], ref txture);
			}
//			if (depthCameras.Count != 0) {
//				state.depth = new byte[depthCameras.Count][];
//				for (int i = 0; i < depthCameras.Count; i++) {
//					Texture2D txture = depthImages [i];
//					state.depth [i] = GetCameraImage (depthCameras [i], ref txture,0);
//				}
//			}
			if (irSensors.Count != 0)
			{
				state.ir = new int[1][];
				state.ir [0] = new int[irSensors.Count];
				for (int i = 0; i < irSensors.Count; i++)
				{
					state.ir[0][i]=irSensors[i].retunDist();
				}
				state.foodornot = new int[1][];
				state.foodornot [0] = new int[irSensors.Count];
				for (int i = 0; i < irSensors.Count; i++)
				{
					state.foodornot[0][i]=irSensors[i].foodtruefalse();
				}
			
			}
			if (GyroSensor.Count != 0) {
				state.gyro = new int[1][];
				state.gyro [0] = new int[3];
				for (int i = 0; i < GyroSensor.Count; i++) {
					state.gyro [0] [0] = GyroSensor [i].returnAngleY ();
					state.gyro [0] [1] = GyroSensor [i].returnAngleX ();
					state.gyro [0] [2] = GyroSensor [i].returnAngleZ ();
					rotationTempX=GyroSensor [i].returnAngleX ();
					rotationTempZ=GyroSensor [i].returnAngleZ ();
				}

			}
			//Debug.Log ("x: " + state.gyro [0] [0]);
			//Debug.Log ("y: " + state.gyro [0] [1]);
			//Debug.Log ("z: " + state.gyro [0] [2]);
			if (groundSensor.Count != 0)
			{
				state.ground = new int[1][];
				state.ground [0] = new int[groundSensor.Count];
				for (int i = 0; i < groundSensor.Count; i++)
				{
					state.ground[0][i] = groundSensor [i].returnFlag ();
				}
			}
		}
		
		public void ResetState ()
		{
			state.Reset ();
		}

		public void StartEpisode ()
		{
			state.reward = new float[11];
			line_length_pre = 0;
			mate_pixels_pre = 0;
			nestColArea_pre = 0;
			pooldistance_pre = 0;
			centerdistance_pre = 0;
		}

		public void EndEpisode ()
		{
			state.endEpisode = true;
		}

		public void Start() {
			action = new Action ();
			state = new State ();


			rotationTempX = 0;
			rotationTempZ = 0;
			rgbImages = new List<Texture2D> (rgbCameras.Capacity);
			foreach (var cam in rgbCameras) {
				rgbImages.Add (new Texture2D (cam.targetTexture.width, cam.targetTexture.height,
					TextureFormat.RGB24, false));
			}
			depthImages = new List<Texture2D> (rgbCameras.Capacity);
			foreach (var cam in depthCameras) {
				depthImages.Add(new Texture2D (cam.targetTexture.width, cam.targetTexture.height,
					TextureFormat.RGB24, false));
			}
			foreach (var cam in depthCameras) {
				cam.depthTextureMode = DepthTextureMode.Depth;
				cam.SetReplacementShader (Shader.Find ("Custom/ReplacementShader"), "");
			}

			line_length_pre = 0;
			mate_pixels_pre = 0;
			nestColArea_pre = 0;
			pooldistance_pre = 0;
			centerdistance_pre = 0;
		}

		public void SetCameraTag(int i){
			foreach (var cam in rgbCameras) {
				cam.tag = i.ToString (); 
			}
		}
		public float measureTargetDistance(){
			Vector3 vec = this.transform.position - target.transform.position;
			float mag = vec.magnitude;
			return mag;
		}
		public byte[] GetCameraImage(Camera cam, ref Texture2D tex) {
			RenderTexture currentRT = RenderTexture.active;
			RenderTexture.active = cam.targetTexture;
			cam.Render();
			tex.ReadPixels(new Rect(0, 0, cam.targetTexture.width, cam.targetTexture.height), 0, 0);
			tex.Apply();
			RenderTexture.active = currentRT;

			state.reward [0] = 0;
			line_length = 0;
			mate_pixels = 0;
			foodColArea = 0;
			nestColArea = 0;
			pooldistance = 0;
			centerdistance = 0;

			for (int y = 0; y < 128; y++) {
				line_left = 0;
				line_right = 0;
				line_flag = false;
				for (int x = 0; x < 128; x++) {
					var col = tex.GetPixel (x, y);
					if (col == targetCol) {//target col=yellow,mate col=blue
						if (!line_flag) {
							line_left = x;
							line_flag = true;

						}
						foodColArea += 1;
						line_right = x;

					} else if (col == mateCol) {
						mate_pixels += 1;
					} else if (col == nestCol) {
						nestColArea += 1;
					}
				}
				
			}		
			
//
			if (mate_pixels > 0) {//if mates are detected
				state.reward [0] += 0f;
				state.reward [1] += 1;
				state.reward [2] += 1;
			}// will remove this part later on
			if (mate_pixels > mate_pixels_pre) {//if getting closer to mate
				state.reward [0] += 0f;
				state.reward [1] += 1.5f;
				state.reward [3] += 1.5f;
			}
			mate_pixels_pre = mate_pixels;
			
			//TEST ONLY
			if ((nestColArea > 0)) {
				// state.reward [0] += 2.5f;
				// state.reward [1] += 2.5f;
				// state.reward [4] += 2.5f;
				if (nestColArea > nestColArea_pre) {
					state.reward [0] += 3f;
					state.reward [1] += 3f;
					state.reward [5] += 3f;
				
					nestColArea_pre = nestColArea;//35% of screem, if food occupy scree size and get closer to nest
				//state.reward [0] += 1f;
				}//state.reward [6] += 1;
			}
			// measurePoolDistance ();
			measureCenterDistance ();

			float targetDis = measureTargetDistance();
			//Debug.Log(targetDis);
			if (targetDis < 7){
				this.SetTarget(0,false,0);
				sc.total_arrival ++;
				Debug.Log(sc.total_arrival);
				nestColArea_pre = 0;
				state.reward [0] += 1000f;
				state.reward [1] += 1000f;
				state.reward [6] += 1000f;
			}
			/* 
			if (pooldistance < pooldistance_pre) {
				
				state.reward[0]+=4f;
				state.reward[1]+=4f;
			}
			pooldistance_pre = pooldistance;

			if (centerdistance < centerdistance_pre) {
				state.reward[0]+=2f;
				state.reward[1]+=2f;
			}
			centerdistance_pre = centerdistance;
		*/



			//will change depends on state.target

			////
			/*
			if (state.target == 0) {
				measurePoolDistance ();
				if(pooldistance<pooldistance_pre){
					state.reward[0]+=4f;
				}
			}
			if (state.target == 255) {
				measurePoolDistance2 ();
				if(pooldistance<pooldistance_pre){
					state.reward[0]+=4f;
				}
			}
			pooldistance_pre = pooldistance;


			*/
			////









			return tex.EncodeToPNG ();

			/*if (coll) {
				Debug.Log ("PLANE TOUCH");
			}else{Debug.Log ("Nothing yet");}*/



		}


		public void measurePoolDistance(){
			tempdist = transform.position - GameObject.FindGameObjectWithTag("AREA").transform.position;
			pooldistance = tempdist.magnitude;
		}

		public void measurePoolDistance2(){
			tempdist = transform.position - GameObject.FindGameObjectWithTag ("AREA2").transform.position;
			pooldistance = tempdist.magnitude;
		}

		public void measureCenterDistance(){
			tempdist2 = transform.position - Center.transform.position;
			centerdistance = tempdist2.magnitude;
		}

		public void SetTarget(int LandmarkCount, bool initial_flag,int i){
			if (initial_flag) {
				state.target = new int[1][];
				state.target [0] = new int[2];
				state.target[0][i] = 255;
			} else {
				switch(state.target[0][0]) {
				case 0:
					state.target [0][0] = 255;
					state.target [0][1] = 0;
					break;
				case 255:
					state.target [0][0] = 0;
					state.target [0][1] = 255;
					break;
				}
			}

			// switch(state.target[0][0]){
			// case 0:
			// 	Ring.GetComponent<Renderer> ().material.color = new Color (0, 1, 1, 1);
			// 	if (Led.Count == 4) {
			// 		Led [0].GetComponent<Renderer> ().material.color = new Color (0.5f, 0.5f, 0.5f, 1);
			// 		Led [1].GetComponent<Renderer> ().material.color = new Color (0.5f, 0.5f, 0.5f, 1);
			// 		Led [2].GetComponent<Renderer> ().material.color = Color.blue;
			// 		Led [3].GetComponent<Renderer> ().material.color = Color.blue;
			// 	}
			// 	break;
			// case 255:
			// 	Ring.GetComponent<Renderer> ().material.color = new Color (1, 1, 0, 1);
			// 	if (Led.Count == 4) {					
			// 		Led [0].GetComponent<Renderer> ().material.color = new Color (0.5f, 0.5f, 0.5f, 1);
			// 		Led [1].GetComponent<Renderer> ().material.color = new Color (0.5f, 0.5f, 0.5f, 1);
			// 		Led [2].GetComponent<Renderer> ().material.color = Color.red;
			// 		Led [3].GetComponent<Renderer> ().material.color = Color.red;
			// 	}
			// 	break;
			// }
		}

		public int TargetInfo(){
			if (state.target [0][0] == 255) {
				return (int)0;
			} else if (state.target[0][1] == 255) {
				return (int)0;//modified this value from 1 to 0
			} else {
				return (int)1234;
			}
		}
	}
}
