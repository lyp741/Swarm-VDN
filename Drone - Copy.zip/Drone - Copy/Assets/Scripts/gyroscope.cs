﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace MLPlayer {
	public class gyroscope : MonoBehaviour {
		public float xAxis;
		public float yAxis;
		public float zAxis;
	
		// Use this for initialization
		void Start () {
		}

		// Update is called once per frame
		void Update () {
		}
		void FixedUpdate(){
			xAxis=transform.rotation.eulerAngles.x;
			yAxis=transform.rotation.eulerAngles.y;
			zAxis=transform.rotation.eulerAngles.z;
		}
		public int returnAngleX(){

			return (int)((xAxis / 360) * 255);
		}
		public int returnAngleY(){

			return (int)((yAxis / 360) * 255);
		}
		public int returnAngleZ(){

			return (int)((zAxis / 360) * 255);
		}
	}
}
