﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Force : MonoBehaviour {

	private MLPlayer.Agent m_agent;
	public Rigidbody drone;
	public GameObject FLR;
	public GameObject FRR;
	public GameObject BLR;
	public GameObject BRR;

	public float b1;
	public float b2;
	public float b3;
	public float b4;


	public float maxRotorForce;

	private Vector3 directionfrontR;
	private Vector3 directionfrontL;
	private Vector3 directionbackL;
	private Vector3 directionbackR;

	// Use this for initialization

	private void Start () {
		m_agent = GetComponent<MLPlayer.Agent> ();
		if (m_agent == null) {
			Debug.Log ("GetComponent<MLPlayer.Agent> () was null.");
		}

	}
	
	// Update is called once per frame

	private void Update(){
		if (Input.GetKey ("z")) {
			print ("z key is held down");
			b1 = 1;
			b2 = 0;
			b3 = 0;
			b4 = 0;
		}
		if (Input.GetKey("x")){
			print ("x key is held down");
			b1 = 0;
			b2 = 1;
			b3 = 0;
			b4 = 0;
		}
		if (Input.GetKey("c")){
			print ("c key is held down");
			b1 = 0;
			b2 = 0;
			b3 = 1;
			b4 = 0;
		}
		if (Input.GetKey("v")){
			print ("v key is held down");
			b1 = 0;
			b2 = 0;
			b3 = 0;
			b4 = 1;
		}
		if (Input.GetKey("b")){
			print ("b key is held down");
			b1 = 1;
			b2 = 1;
			b3 = 1;
			b4 = 1;
		}

		float frontLeftRotor = maxRotorForce * ((m_agent.action.fLR)+b1);
		float frontRightRotor = maxRotorForce * ((m_agent.action.fRR)+b2);
		float backLeftRotor = maxRotorForce * ((m_agent.action.bLR)+b3);
		float backRightRotor = maxRotorForce * ((m_agent.action.bRR)+b4);

		directionfrontL = transform.up * frontLeftRotor * Time.deltaTime;
		directionfrontR = transform.up * frontRightRotor * Time.deltaTime;
		directionbackL = transform.up * backLeftRotor * Time.deltaTime;
		directionbackR = transform.up * backRightRotor * Time.deltaTime;

		drone.AddForceAtPosition (directionfrontL, FLR.transform.position, ForceMode.Acceleration);
		drone.AddForceAtPosition (directionfrontR, FRR.transform.position, ForceMode.Acceleration);
		drone.AddForceAtPosition (directionbackL, BLR.transform.position, ForceMode.Acceleration);
		drone.AddForceAtPosition (directionbackR, BRR.transform.position, ForceMode.Acceleration);

		b1 = 0;
		b2 = 0;
		b3 = 0;
		b4 = 0;
	}






}



