﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;
using System.Threading;
using MsgPack;

namespace MLPlayer {
	public class SceneController : MonoBehaviour {

		protected static SceneController instance;
		public static SceneController Instance {
			get {
				if(instance == null) {
					instance = (SceneController) FindObjectOfType(typeof(SceneController));
					if (instance == null) {
						Debug.LogError("An instance of " + typeof(SceneController) + 
						               " is needed in the scene, but there is none.");
					}
				}
				return instance;
			}
		}

		[SerializeField] string domain;
		[SerializeField] string path;
		[SerializeField] int port;
		[SerializeField] int TimestepPerEpisode;
		[SerializeField] int MaxEpisode;
		[SerializeField] List<Text> texts;
		[SerializeField] List<Rigidbody> Drone;

		public int total_arrival = 0;
		[Range(0.1f, 10.0f)]
		[SerializeField] float timeScale = 1.0f;

		[SerializeField] List<Agent> agents;
		[SerializeField] List<Landmarks_Random_Move> LandmarkMove;
		private List<IAIClient> clients;

		private List<Vector3> firstLocation;
		private int agentReceiveCounter;
		MsgPack.BoxingPacker packer = new MsgPack.BoxingPacker ();
		public Dictionary<System.Object, System.Object>order;
		public static ManualResetEvent received = new ManualResetEvent(false);
		private Mutex mutAgent;
		public GameObject SwarmCenter;
		private Vector3 SwarmCenterPosition;
		private Vector3 SwarmCenterTemp;
		public GameObject Pole;
		private Vector3 tempCDmag;
		private Vector3 tempGLmag;
		private float insideOrNot;
		private Vector3 tempForAll;

		string GetUrl(string domain, int port, string path) {
			return "ws://" + domain + ":" + port.ToString () + "/" + path;
		}

		private int cycle=0;
		private int timestep = 0;
		private int episode = 1;
		private int arrival=123456789;
		private int hit_count = 123456789;

		[SerializeField] List<Landmark> landmarks;


		[SerializeField] float GoalRange;
		private float dist;
		private float faDist;
		private Vector3 tempVec;
		private bool game = true;
		private int break_count = 0;
		System.IO.StreamWriter sw;

		public int[]arrival_per_robot;
		public int[]hit_per_robot;
		public float[]reward_rate;



		enum ExperienceMode {AGGREGATION,DISTRIBUTE}
		[SerializeField] ExperienceMode experienceMode;

		void Start () {
			clients = new List<IAIClient> ();
			firstLocation = new List<Vector3> ();
			for (int i = 0; i < agents.Count; i++) {
				firstLocation.Add (agents [i].transform.position);
				agents [i].SetCameraTag (i);
			}

			if (experienceMode == ExperienceMode.AGGREGATION) {
				clients.Add (new AIClient (GetUrl (domain, port, path),
				                           OnMessage, agents[0]));	
			} else if (experienceMode == ExperienceMode.DISTRIBUTE) {
				int cnt = 0;
				foreach (var agent in agents) {
					clients.Add (
						new AIClient (GetUrl (domain, port + cnt, path),
					              OnMessage, agent));
					cnt++;
				}
			}
			System.IO.Directory.CreateDirectory (Application.dataPath + "/log");
			sw = new System.IO.StreamWriter (Application.dataPath + "/log/log.txt", true);
			sw.Write ("start experiment\n");
			sw.Close ();
			//			StartNewEpisode ();
			mutAgent = new Mutex();
			arrival_per_robot = new int[agents.Count];
			hit_per_robot = new int[agents.Count];
			reward_rate = new float[11];
			SwarmCenterPosition = new Vector3 (0, 0, 0);
			SwarmCenterTemp = new Vector3 (0, 0, 0);
			tempCDmag = new Vector3 (0, 0, 0);
			tempGLmag = new Vector3 (0, 0, 0);
			insideOrNot = 0;
			tempForAll = new Vector3 (0, 0, 0);
		}

		void OnMessage(byte[] msg, Agent agent) {
			mutAgent.WaitOne();
			if (experienceMode == ExperienceMode.AGGREGATION) {
				agentReceiveCounter += agents.Count;
			} else if (experienceMode == ExperienceMode.DISTRIBUTE) {
				agentReceiveCounter++;
			}
			mutAgent.ReleaseMutex();

			order = (Dictionary<System.Object, System.Object>)packer.Unpack (msg);

			var originalKey = new Dictionary<string, byte[]>();
			foreach (byte[] key in order.Keys) {
				originalKey.Add (System.Text.Encoding.UTF8.GetString(key), key);
			}

			string command = System.Text.Encoding.UTF8.GetString((byte[])order [originalKey ["command"]]);

			if (experienceMode == ExperienceMode.AGGREGATION) {
				for (int i = 0; i < agents.Count; i++) {
					agents [i].action.Set (command.Substring (i, 1));
				}
			} else if (experienceMode == ExperienceMode.DISTRIBUTE) {
				agent.action.Set (command);
			}

			if (agentReceiveCounter == agents.Count) {
				received.Set();
			}
		}

		public void TimeOver() {
			foreach (var agent in agents) {
				agent.EndEpisode ();
			}

		}

		void StartNewEpisode() {
			SetTargetList (agents);
			for (int i = 0; i < agents.Count; i++) {
				agents [i].transform.position = firstLocation [i];
				agents [i].transform.rotation = Quaternion.Euler (0f, Random.Range(0f,360f), 0f);
				agents [i].StartEpisode ();
			}
			for (int i=0; i<Drone.Count; i++) {
				Drone [i].velocity = Vector3.zero;
			
			}
		}
		void RecordEpisode(){

			for (int i = 0; i < agents.Count; i++) {
				for (int j = 0; j < 11; j++) {
					reward_rate [j] += agents [i].state.reward [j];
				}
			}
			sw = new System.IO.StreamWriter (Application.dataPath + "/log/reward_rate.txt", true);
			for (int i = 0; i < 11; i++) {
				sw.Write ("{0},",reward_rate[i]);
			}
			sw.Write ("\n");
			sw.Close ();
			reward_rate = new float[11];
			sw=new System.IO.StreamWriter (Application.dataPath + "/log/Arrival.txt", true);
			sw.Write ("{0}, ",
						total_arrival);
			sw.Close();	
			total_arrival = 0;
				
		}
		void rewardForFalling(Agent agent, int robot_num){
			agent.state.reward [0] -= 10f;
			agent.state.reward [1] -= 10f;
			agent.state.reward [2] += 1;
		}

		void rewardForBeingInside(Agent agent, int robot_num){
			agent.state.reward [0] += 5;
			agent.state.reward [1] += 5;
		}
	


		void RewardForApproachToTarget(Agent agent,int robot_num){

			int a = 0;

			for (int i=1; i<3; i++) {
				if (agent.state.gyro [0] [i]>0&&agent.state.gyro [0] [i]<60) {
					a=agent.state.gyro[0][i]; 
					agent.state.reward [0] -= (a/10);
					agent.state.reward [1] -= (a/10);
					a=0;
				}
				if (agent.state.gyro [0] [i]>195&&agent.state.gyro [0] [i]<255) {
					a=agent.state.gyro[0][i]; 
					agent.state.reward [0] -= ((255-a)/10);
					agent.state.reward [1] -= ((255-a)/10);
					a=0;
				}
			}

			bool f=false;
			for (int i = 0; i < agent.state.ir [0].Length; i++) {
				if (agent.state.ir [0] [i] > 252&& !f) {
					//					hit_count++;
					//					agent.state.reward [0] -= 1.0f;
					agent.state.reward [0] -= 1.5f;
					agent.state.reward [1] -= 1.5f;
					f = true;
					//					break;
				}
				if (agent.state.ir [0] [i] > 192&& !f) {
					//					hit_count++;
					//					agent.state.reward [0] -= 1.0f;
					agent.state.reward [0] -= 1f;
					agent.state.reward [1] -= 1f;
					f = true;
					//					break;
				}
				if (agent.state.ir [0] [i] > 128&& !f) {
					//					hit_count++;
					//					agent.state.reward [0] -= 1.0f;
					agent.state.reward [0] -= 0.5f;
					agent.state.reward [1] -= 0.5f;
					f = true;
					//					break;
				}
				if (agent.state.ir [0] [i] > 64) {
					hit_count++;
					agent.state.reward [0] -= 0.3f;
					agent.state.reward [1] -= 0.3f;
					//hit_per_robot [robot_num] += 1;
					break;
				}
			}		
		}


		public float centerDistance(Agent agent){
			tempCDmag = new Vector3 (0, 0, 0);
			tempCDmag = agent.transform.position - SwarmCenterPosition;
			return tempCDmag.magnitude;
		}

		public float goalDistance(Agent agent){
			tempGLmag = new Vector3 (0, 0, 0);
			tempGLmag = agent.transform.position - Pole.transform.position;
			return tempGLmag.magnitude;
		}


		public float insideGoal(Agent agent){
			insideOrNot = 0;
			tempForAll = new Vector3 (0, 0, 0);
			tempForAll = Pole.transform.position - agent.transform.position;
			tempForAll.y = 0;
			if (tempForAll.magnitude < 5) {
				insideOrNot = 1;
			}

			return insideOrNot;
		}

		void FixedUpdate() {
			if (game) {

				cycle++;
				if (cycle >= (MaxEpisode * TimestepPerEpisode) * 10) {
					Application.Quit ();//cycle end in 50000 timestep
				}

				if (cycle == 1) {
					StartNewEpisode ();
				}
				/*for(int i=0;i<agents.Count;i++){
					Debug.Log(agents[i].state.reward[0]);
				}*/
			
				if (cycle % 50 == 1) {
					/*for (int i = 0; i < agents.Count; i++) {
						sw = new System.IO.StreamWriter (Application.dataPath + "/log/log.txt", true);
						sw.Write ("{0},{1},{2},{3},{4},{5}\n",
						          agents [i].transform.position.x,
						          agents [i].transform.position.y,
						          agents [i].transform.position.z,
						          agents [i].transform.eulerAngles.x, 
						          agents [i].transform.eulerAngles.y,
						          agents [i].transform.eulerAngles.z);
						sw.Close ();
					}
					*/

					sw=new System.IO.StreamWriter (Application.dataPath + "/log/SwarmDistribution.txt", true);
					sw.Write ("{0}, ",
					          timestep);
					sw.Close();
					for (int i = 0; i < agents.Count; i++) {
						sw=new System.IO.StreamWriter (Application.dataPath + "/log/SwarmDistribution.txt", true);
						sw.Write ("{0}, ",
						          centerDistance (agents [i]));
						sw.Close();
					}
					sw=new System.IO.StreamWriter (Application.dataPath + "/log/SwarmDistribution.txt", true);
					sw.Write ("\n");
					sw.Close();

					sw=new System.IO.StreamWriter (Application.dataPath + "/log/DistanceFromGoal.txt", true);
					sw.Write ("{0}, ",
					          timestep);
					sw.Close();
					for (int i = 0; i < agents.Count; i++) {
						sw=new System.IO.StreamWriter(Application.dataPath + "/log/DistanceFromGoal.txt", true);
						sw.Write ("{0}, ",
						          goalDistance (agents [i]));
						sw.Close();
					}
					sw=new System.IO.StreamWriter (Application.dataPath + "/log/DistanceFromGoal.txt", true);
					sw.Write ("\n");
					sw.Close();

					sw=new System.IO.StreamWriter (Application.dataPath + "/log/InsideOrNot.txt", true);
					sw.Write ("{0}, ",
					          timestep);
					sw.Close();	
					for (int i = 0; i < agents.Count; i++) {
						sw=new System.IO.StreamWriter(Application.dataPath + "/log/InsideOrNot.txt", true);
						sw.Write ("{0}, ",
						         insideGoal (agents [i]));
						sw.Close();
					}
					sw=new System.IO.StreamWriter (Application.dataPath + "/log/InsideOrNot.txt", true);
					sw.Write ("\n");
					sw.Close();
					
				}

				if (cycle % 10 == 1) {
					Time.timeScale = timeScale;




					timestep++;
					/*
					if (timestep == (TimestepPerEpisode * MaxEpisode)) {
						TimeOver ();
					}*/
				if ((timestep % TimestepPerEpisode == 0)) {
					TimeOver ();

					RecordEpisode ();
					episode++;
					
					//timestep = 1;

				}
					if (timestep % 500 == 0) {
						//LandmarkMove[0].randomMove();
					}
				if (texts.Count >= 3) {
					Debug.Log(total_arrival);
					texts [0].text = "Episode : " + episode.ToString ();
					texts [1].text = "Timestep : " + timestep.ToString ();
					texts [2].text = "Arrival : " + total_arrival.ToString ();
				}



				agentReceiveCounter = 0;
				received.Reset ();

				for (int i = 0; i < agents.Count; i++) {
					agents [i].UpdateState ();
						/*if (insideGoal (agents [i]) == 1) {
							rewardForBeingInside(agents[i], i);
						}*/

					RewardForApproachToTarget (agents [i], i);
						if (agents [i].transform.position.y < 0) {
							agents [i].transform.position = firstLocation [i];
							agents [i].transform.rotation = Quaternion.Euler (0f, Random.Range (0f, 360f), 0f);
							rewardForFalling(agents [i] ,i);
						}
						if ((agents [i].transform.eulerAngles.z > 85 && agents [i].transform.eulerAngles.z < 275)) {
							agents [i].transform.position = firstLocation [i];
							agents [i].transform.rotation = Quaternion.Euler (0f, Random.Range(0f,360f), 0f);
							rewardForFalling(agents [i] ,i);
						}
						if ((agents [i].transform.eulerAngles.x > 85 && agents [i].transform.eulerAngles.x < 275)) {
							agents [i].transform.position = firstLocation [i];
							agents [i].transform.rotation = Quaternion.Euler (0f, Random.Range(0f,360f), 0f);
							rewardForFalling(agents [i] ,i);
						}	
						SwarmCenterTemp.x += agents [i].transform.position.x;
						SwarmCenterTemp.y += agents [i].transform.position.y;
						SwarmCenterTemp.z += agents [i].transform.position.z;

						if (experienceMode == ExperienceMode.DISTRIBUTE) {
							clients [i].PushAgentState (agents [i].state);
						}
					}
					SwarmCenterPosition = SwarmCenterTemp / agents.Count;
					SwarmCenter.transform.position = SwarmCenterPosition;
					SwarmCenterTemp = new Vector3 (0, 0, 0);




					if (experienceMode == ExperienceMode.AGGREGATION) {
						clients[0].PushAgentState (conbineState (agents));
					}
					received.WaitOne ();

					// TODO all agents have same value
					if (agents [0].state.endEpisode) {
						Resources.UnloadUnusedAssets ();
						game = false;
					}

					foreach (var agent in agents) {
						agent.ResetState ();
					}
				}
			} else {
				for (int i =0;i< agents.Count;i++) {
					agents [i].action.Set ("0");
				}
				break_count++;
				if (break_count >= 50) {
					break_count = 0;
					StartNewEpisode ();
					game = true;
				}
			}
		}
		


		State conbineState(List<Agent> agents){
			State result = new State ();
			result.image = new byte[agents.Count][];
			result.reward = new float[agents.Count];
			if (agents [0].state.depth != null) {
				result.depth = new byte[agents.Count][];
			}
			if (agents [0].state.ir != null) {
				result.ir = new int[agents.Count][];
			}
			if (agents [0].state.ground != null) {
				result.ground = new int[agents.Count][] ;
			}
			if (agents [0].state.gyro != null) {
				result.gyro = new int[agents.Count][] ;
			}
			if (agents [0].state.target != null) {
				result.target = new int[agents.Count][];
			}

			for (int i = 0; i < agents.Count; i++) {
				result.image [i] = agents [i].state.image [0];
				result.reward [i] = agents [i].state.reward[0];
				if (agents [0].state.depth != null) {
					result.depth [i] = agents [i].state.depth [0];
				}
				if (agents [0].state.ir != null) {
						result.ir [i] = agents [i].state.ir [0];
				}
				if (agents [0].state.ground != null) {
					result.ground [i] = agents [i].state.ground [0];
				}
				if (agents [0].state.gyro != null) {
						result.gyro [i] = agents [i].state.gyro [0];
				}
				if (agents [0].state.target != null) {
					result.target [i] = agents [i].state.target [0];
				}

			}
			result.endEpisode = agents [0].state.endEpisode;
			return result;
		}

		void SetTargetList(List<Agent> agents){
//			only two landmark experiment act right
					for (int i = 0; i < agents.Count; i++) {
						agents [i].SetTarget (landmarks.Count, true, 1);
					}

				}

			}
		}
