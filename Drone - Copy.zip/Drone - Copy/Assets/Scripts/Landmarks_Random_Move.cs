﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace MLPlayer
{
public class Landmarks_Random_Move : MonoBehaviour {
		public GameObject Pollandmark;
		public Vector3 Position;
		


	// Use this for initialization
		void Start () {
			Position = Pollandmark.transform.position;
		}
	
	// Update is called once per frame
		void Update () {
		
		}
		public void randomMove(){
			Position = Random.insideUnitSphere * 23;
			Position.y = 3;
			Pollandmark.transform.position = Position;
		
		}

			
	}
}