﻿using UnityEngine;
using System.Collections.Generic;
using System.Threading;
using MsgPack;

namespace MLPlayer
{
public class FOOD : MonoBehaviour {

		public Renderer rend;
		public Collider coll;
		public Rigidbody rb;
		private Vector3 origin;
		private	Vector3 position;
		private float distFromOrigin;

	// Use this for initialization
	void Start () {
			rend = GetComponent<Renderer> ();
			coll = GetComponent<Collider> ();
			rb = GetComponent<Rigidbody>();
			rend.enabled = true;
			coll.enabled = true;


	}
	void disableRendAndColl(){
			rend.enabled = false;
			coll.enabled = false;
			rb.constraints = RigidbodyConstraints.FreezeAll;

		}

	void enableRendandColl(){
			rend.enabled = true;
			coll.enabled = true;
			rb.constraints = RigidbodyConstraints.None;

		}




	

	// Update is called once per frame
	void Update () {
			origin = GameObject.FindGameObjectWithTag("AREA").transform.position;
			position = gameObject.transform.position - origin;
			position.y = 0;
			distFromOrigin = position.magnitude;
			if (distFromOrigin < 2.5) {
				disableRendAndColl ();

			
			} else {
				enableRendandColl ();
			}
	
	}
}
}