﻿using UnityEngine;
using System.Collections.Generic;

namespace MLPlayer {
	public class Action {
		public float right_Wheel;
		public float left_Wheel;
		public void Clear() {
			right_Wheel = 0;
			left_Wheel = 0;
		}

		public void Set(string command) {
			switch (command) {
			case "0":
				right_Wheel = 1;
				left_Wheel = 1;
				break;
			case "1":
				right_Wheel = 2;//1
				left_Wheel = 2;//1
				break;
			case "2":
				right_Wheel = 2;//1
				left_Wheel = -2;//-1
				break;
			case "3":
				right_Wheel = -2;//-1
				left_Wheel = 2;//1
				break;
			case "4":
				right_Wheel = 2;//1
				left_Wheel = 0;//0
				break;
			case "5":
				right_Wheel = 0;//0
				left_Wheel = 2;//1
				break;
			case "6":
				right_Wheel = 1;//0.5f
				left_Wheel = 2;//1
				break;
			case "7":
				right_Wheel = 2;//1
				left_Wheel = 1;//0.5f
				break;
			}
		}
	}
}