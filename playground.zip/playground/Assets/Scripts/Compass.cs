﻿using UnityEngine;
using System.Collections;

namespace MLPlayer {
	public class Compass : MonoBehaviour {
		private float Angle;

	// Use this for initialization
		void Start () {
			Angle = 0;
		}
	
	// Update is called once per frame
		void FixedUpdate () {
			Angle = transform.eulerAngles.y;
			//Debug.Log (returnAngle());

		}	

		public int returnAngle()
		{
			return (int)((Angle/360) * 255);
		}
	}
}
